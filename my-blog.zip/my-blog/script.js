function sayHello() {
  alert("Привет! 👋 Рад, что ты зашел на мой сайт!");
}
